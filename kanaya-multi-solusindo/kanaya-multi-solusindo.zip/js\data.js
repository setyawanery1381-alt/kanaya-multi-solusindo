/**
 * PT Kanaya Multi Solusindo - Master Data Store & CMS State Management
 * Aligned 100% with PRD & Visual Mockup Reference
 */

const DEFAULT_KMS_DATA = {
  company: {
    name: "PT Kanaya Multi Solusindo",
    shortName: "KMS",
    established: 2024,
    tagline: "General Supplier yang Mendukung Kebutuhan Bisnis & Industri Anda",
    subheadline: "PT Kanaya Multi Solusindo hadir sebagai solusi pengadaan dengan menyediakan beragam produk untuk mendukung kebutuhan bisnis, operasional, dan industri.",
    aboutShort: "PT Kanaya Multi Solusindo bergerak di bidang General Supplier dengan menyediakan beragam produk untuk memenuhi kebutuhan bisnis, operasional, dan industri, meliputi Plastic, Packaging, Office Stationery, Safety Equipment, Chemical, Consumable, dan Printing.",
    aboutFull: "PT Kanaya Multi Solusindo merupakan perusahaan General Supplier yang menyediakan berbagai kebutuhan produk dan material untuk mendukung aktivitas bisnis, operasional, dan industri.\n\nDidirikan pada tahun 2024, PT Kanaya Multi Solusindo berfokus pada pengadaan dan penyediaan berbagai kebutuhan, mulai dari Plastic, Packaging, Office Stationery, Safety Equipment, Chemicals, Consumables, hingga Printing.\n\nDengan pendekatan yang berorientasi pada kebutuhan pelanggan, kami berkomitmen untuk menjadi mitra pengadaan yang terpercaya serta memberikan solusi yang efektif, efisien, dan tepat guna.",
    contacts: {
      phone: "0813-1052-840",
      whatsapp: "0813-1052-840",
      whatsappNumber: "628131052840",
      emailSales: "sales@kanayamulti.com",
      emailAdmin: "admin@kanayamulti.com",
      instagram: "@kanayamultisolusindo",
      instagramUrl: "https://instagram.com/kanayamultisolusindo",
      tiktok: "@pt_kanayamultisolusindo",
      tiktokUrl: "https://www.tiktok.com/@pt_kanayamultisolusindo?_r=1&_t=ZS-99aLXp9ql8C",
      linkedin: "PT Kanaya Multi Solusindo",
      linkedinUrl: "https://www.linkedin.com/in/pt-kanaya-multi-solusindo-661959435/",
      address: "Ruko Sentra EM.6 Harapan Indah - Bekasi - Jawa Barat",
      city: "Bekasi, Jawa Barat - Indonesia",
      operationalHours: "Senin - Jumat: 08:30 - 17:00 WIB",
      mapsUrl: "https://maps.google.com/?q=Ruko+Sentra+EM.6+Harapan+Indah+Bekasi",
      footerTagline: "General Supplier untuk kebutuhan bisnis, operasional, dan industri. Mitra terpercaya pengadaan barang korporat berkualitas tinggi."
    }
  },

  // 4 Default Hero Slides for the Slideshow
  heroSlides: [
    {
      id: "slide-1",
      badge: "General Supplier & B2B Procurement Partner",
      title: "General Supplier Terpercaya untuk Kebutuhan Operasional & Bisnis",
      subtitle: "PT Kanaya Multi Solusindo hadir sebagai mitra pengadaan terintegrasi dengan menyediakan beragam produk industri berkualitas prima.",
      image: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=1200&q=85",
      tag: "Suplai Cepat & Resmi",
      highlights: [
        "Katalog Produk Lengkap & Siap Pasok",
        "Legalitas Perusahaan Lengkap & Faktur Pajak Resmi",
        "Jangkauan Pengiriman Seluruh Wilayah Industri"
      ],
      btnPrimaryText: "Lihat Produk",
      btnPrimaryLink: "#products",
      btnSecondaryText: "Hubungi Kami",
      btnSecondaryLink: "#contact"
    },
    {
      id: "slide-2",
      badge: "Packaging & Material Plastik Industri",
      title: "Solusi Lengkap Packaging & Plastic Stretch Film Industri",
      subtitle: "Menyediakan Plastic Stretch Film kualitas prima, bubble wrap tebal, lakban OPP, dan kardus corrugated untuk proteksi kargo maksimal.",
      image: "https://images.unsplash.com/photo-1587293852726-70cdb56c2866?auto=format&fit=crop&w=1200&q=85",
      tag: "Proteksi Kargo Pallet",
      highlights: [
        "Plastic Stretch Film Hand & Machine Roll",
        "Bubble Wrap Tebal & Dus Corrugated Box",
        "Standar Proteksi Kargo Industri & Siap Ekspor"
      ],
      btnPrimaryText: "Katalog Plastik",
      btnPrimaryLink: "#products",
      btnSecondaryText: "Ajukan Penawaran",
      btnSecondaryLink: "#contact"
    },
    {
      id: "slide-3",
      badge: "Workplace Safety & Standar K3",
      title: "Perlengkapan Keselamatan Kerja (APD) & Safety Industri",
      subtitle: "Mendukung kepatuhan standar K3 di lingkungan kerja pabrik, pergudangan, dan proyek dengan perlengkapan keselamatan bersertifikasi.",
      image: "https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=1200&q=85",
      tag: "Standar Sertifikasi K3",
      highlights: [
        "Helm Safety, Rompi K3, Kacamata & Sarung Tangan",
        "Sepatu Safety Standar Pabrik & Konstruksi",
        "Perlindungan Optimal Tenaga Kerja Industri"
      ],
      btnPrimaryText: "Perlengkapan APD",
      btnPrimaryLink: "#products",
      btnSecondaryText: "Konsultasi Safety",
      btnSecondaryLink: "#contact"
    },
    {
      id: "slide-4",
      badge: "Mitra Pengadaan B2B Terpercaya",
      title: "Bukan Sekadar Penyedia, Kami Hadir sebagai Mitra Strategis",
      subtitle: "Kerja sama yang baik dibangun melalui integritas, kecepatan suplai, kualitas produk teruji, dan komitmen pelayanan jangka panjang.",
      image: "https://images.unsplash.com/photo-1521791136064-7986c2920216?auto=format&fit=crop&w=1200&q=85",
      tag: "Kemitraan Jangka Panjang",
      highlights: [
        "Sistem Pembayaran TOP (Term of Payment) Fleksibel",
        "Dedicated Account Manager yang Responsif",
        "Garansi Mutu Produk & Pelayanan Prima"
      ],
      btnPrimaryText: "Lihat Klien Kami",
      btnPrimaryLink: "#clients",
      btnSecondaryText: "Mulai Kerja Sama",
      btnSecondaryLink: "#contact"
    }
  ],

  vision: "Menjadi perusahaan yang mandiri, unggul, terpercaya, dan berorientasi pada keberlanjutan, serta mampu memberikan dampak positif bagi lingkungan sekitar.",
  
  missions: [
    "Memberikan produk dan pelayanan terbaik dengan mengutamakan kualitas, daya saing, serta solusi yang tepat sesuai kebutuhan pelanggan.",
    "Membangun dan mempertahankan kepercayaan pelanggan melalui kinerja yang efektif, efisien, konsisten, dan profesional.",
    "Menghadirkan solusi pengadaan yang inovatif dan tepat guna untuk mendukung kebutuhan serta perkembangan bisnis para mitra."
  ],

  values: [
    {
      id: "profesional",
      title: "Profesional & Terpercaya",
      desc: "Menjunjung profesionalisme dan integritas dalam setiap layanan.",
      icon: "shield-check"
    },
    {
      id: "customer-focus",
      title: "Customer Focus",
      desc: "Menjadikan kebutuhan dan kepuasan pelanggan sebagai prioritas utama.",
      icon: "users"
    },
    {
      id: "kualitas-pelayanan",
      title: "Kualitas & Pelayanan",
      desc: "Berkomitmen memberikan produk berkualitas dan pelayanan yang terus dikembangkan.",
      icon: "star"
    }
  ],

  stats: [
    { number: "500+", label: "Produk Lengkap", sublabel: "Solusi terpadu berbagai kategori" },
    { number: "100+", label: "Klien Korporat", sublabel: "Mitra B2B dan industri manufaktur" },
    { number: "10+", label: "Sektor Industri", sublabel: "Otomotif, logam, logistik & perkantoran" }
  ],

  whyKanaya: {
    badge: "Keunggulan Kompetitif B2B",
    title: "Mengapa Perusahaan Memilih Bermitra dengan Kanaya?",
    subtitle: "Kami bukan sekadar penyedia barang, melainkan mitra strategis pengadaan yang menjamin legalitas resmi, keaslian mutu produk, serta kepastian jadwal suplai untuk kelancaran operasional industri Anda.",
    items: [
      {
        id: "profesional",
        badge: "Legalitas 100% Resmi",
        title: "Profesional & Terpercaya",
        desc: "Menjunjung tinggi integritas, transparansi transaksi, dan kepatuhan administrasi.",
        points: [
          "Perusahaan Berbadan Hukum Resmi (PT)",
          "Faktur Pajak PPN & e-Billing Sah",
          "Sistem TOP (Term of Payment) Fleksibel"
        ]
      },
      {
        id: "customer-focus",
        badge: "Layanan Cepat & Fleksibel",
        title: "Customer Focus",
        desc: "Menjadikan kebutuhan dan jadwal produksi pelanggan sebagai prioritas utama pelayanan.",
        points: [
          "Dedicated Account Representative B2B",
          "Respon Cepat WhatsApp & Penawaran Hitungan Jam",
          "Pengiriman Terjadwal Langsung ke Pabrik / Gudang"
        ]
      },
      {
        id: "kualitas-pelayanan",
        badge: "Garansi Mutu 100%",
        title: "Kualitas & Pelayanan",
        desc: "Standar mutu teruji dengan jaminan penggantian barang untuk kepuasan mitra.",
        points: [
          "Produk Terstandarisasi K3 & Mutu Industri",
          "Garansi Retur 100% Jika Barang Cacat / Tidak Sesuai",
          "Penyediaan Sampel Produk untuk Trial"
        ]
      }
    ],
    guarantees: [
      { icon: "file-check-2", title: "Faktur Pajak Sah", desc: "Legalitas PT & PPN resmi" },
      { icon: "clock", title: "Fast Response", desc: "Penawaran hitungan jam" },
      { icon: "shield-check", title: "Garansi 100%", desc: "Retur barang bila cacat" },
      { icon: "truck", title: "Suplai Rutin", desc: "Pengiriman se-Jabodetabek" }
    ]
  },

  closingCta: {
    title: "Bukan Sekadar Penyedia, Kami Hadir sebagai Mitra.",
    desc: "Kami percaya bahwa kerja sama yang baik dibangun melalui kepercayaan, profesionalitas, kualitas, dan komitmen. Kanaya Multi Solusindo berupaya memahami kebutuhan pelanggan dan memberikan solusi pengadaan yang tepat untuk mendukung kebutuhan bisnis dan operasional."
  },

  solutions: [
    {
      id: "business-ops",
      title: "Business & Operational Supplies",
      desc: "Mendukung kebutuhan perlengkapan dan consumable untuk aktivitas operasional bisnis Anda dengan efisiensi pengadaan tepat waktu.",
      badge: "Operasional Bisnis",
      icon: "briefcase"
    },
    {
      id: "packaging-solutions",
      title: "Packaging Solutions",
      desc: "Mendukung kebutuhan pengemasan, penyimpanan, dan distribusi logistik barang secara aman dan terlindungi dari kerusakan.",
      badge: "Proteksi & Distribusi",
      icon: "package"
    },
    {
      id: "workplace-safety",
      title: "Workplace Safety",
      desc: "Menyediakan kebutuhan perlengkapan keselamatan kerja (APD) komprehensif untuk mendukung keamanan maksimal di lingkungan kerja.",
      badge: "Kesehatan & Keselamatan Kerja",
      icon: "shield"
    },
    {
      id: "cleaning-facility",
      title: "Cleaning & Facility Needs",
      desc: "Mendukung kebutuhan kebersihan dan perawatan area kerja melalui produk chemical terstandar dan perlengkapan sanitasi teruji.",
      badge: "Higienitas & Kebersihan",
      icon: "sparkles"
    }
  ],

  categories: [
    {
      id: "plastic",
      name: "Plastic",
      title: "Material Plastik & Wrapping",
      desc: "Berbagai material dan kebutuhan plastik untuk packaging dan operasional industri.",
      image: "https://images.unsplash.com/photo-1587293852726-70cdb56c2866?auto=format&fit=crop&w=900&q=80",
      itemCount: "9 Varian Utama"
    },
    {
      id: "packaging",
      name: "Packaging",
      title: "Solusi Kemasan & Kardus",
      desc: "Solusi kemasan untuk mendukung kebutuhan pengemasan, penyimpanan, dan distribusi.",
      image: "https://images.unsplash.com/photo-1530587191325-3db32d826c18?auto=format&fit=crop&w=600&q=80",
      itemCount: "Kardus, Lakban, Strapping"
    },
    {
      id: "stationery",
      name: "Office Stationery",
      title: "Alat Tulis & Kantor",
      desc: "Kebutuhan alat tulis dan perlengkapan kantor untuk mendukung aktivitas operasional.",
      image: "https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?auto=format&fit=crop&w=600&q=80",
      itemCount: "Kertas, Map, Pulpen, Klip"
    },
    {
      id: "safety",
      name: "Safety Equipment",
      title: "Perlengkapan K3 / APD",
      desc: "Perlengkapan keselamatan untuk mendukung keamanan di lingkungan kerja industri & proyek.",
      image: "https://images.unsplash.com/photo-1578575437130-527eed3abbec?auto=format&fit=crop&w=600&q=80",
      itemCount: "Helm, Rompi, Sarung Tangan, Sepatu"
    },
    {
      id: "chemical",
      name: "Chemical",
      title: "Chemical & Kebersihan",
      desc: "Produk chemical dan kebutuhan kebersihan untuk mendukung aktivitas operasional.",
      image: "https://images.unsplash.com/photo-1584813470613-5b1c1cad3d69?auto=format&fit=crop&w=600&q=80",
      itemCount: "Pembersih Lantai, Disinfektan, Kaca"
    },
    {
      id: "consumable",
      name: "Consumable",
      title: "Consumable Operasional",
      desc: "Berbagai kebutuhan consumable untuk mendukung aktivitas bisnis dan operasional harian.",
      image: "https://images.unsplash.com/photo-1583947215259-38e31be8751f?auto=format&fit=crop&w=600&q=80",
      itemCount: "Tissue, Kantong Sampah, Masker"
    },
    {
      id: "printing",
      name: "Printing",
      title: "Percetakan & Cetak Dokumen",
      desc: "Kebutuhan printing untuk mendukung kebutuhan bisnis, promosi, dan operasional administrasi.",
      image: "https://images.unsplash.com/photo-1562654501-a0ccc0fc3fb1?auto=format&fit=crop&w=600&q=80",
      itemCount: "Brosur, Label Stiker, Form NCR"
    }
  ],

  products: [
    {
      id: "plastic-stretch-film",
      categoryId: "plastic",
      name: "Plastic Stretch Film",
      categoryName: "Plastic",
      tag: "Best Seller",
      badge: "Proteksi Kemasan",
      shortDesc: "Material stretch film elastis tinggi untuk mengamankan barang pallet saat pengiriman dan penyimpanan.",
      fullDesc: "Plastic stretch film dirancang khusus untuk melindungi produk dari debu, kelembapan, kotoran, dan goncangan selama proses penyimpanan dan distribusi pengiriman barang di gudang maupun ekspedisi logistik.",
      image: "https://images.unsplash.com/photo-1587293852726-70cdb56c2866?auto=format&fit=crop&w=900&q=80",
      gallery: [
        "https://images.unsplash.com/photo-1587293852726-70cdb56c2866?auto=format&fit=crop&w=900&q=80",
        "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=900&q=80",
        "https://images.unsplash.com/photo-1587293852726-70cdb56c2866?auto=format&fit=crop&w=900&q=80"
      ],
      advantages: [
        "Kuat dan sangat elastis dengan daya regang optimal",
        "Transparan, higienis, dan memiliki daya rekat satu sisi yang rapi",
        "Tahan terhadap robekan sudut tajam dan kelembaban udara",
        "Cocok untuk hand roll maupun mesin wrapping pallet industri"
      ],
      specs: [
        { key: "Material", val: "LLDPE (Linear Low-Density Polyethylene)" },
        { key: "Ketebalan", val: "10 - 25 mikron (Tersedia: 12µ, 15µ, 17µ, 20µ, 25µ)" },
        { key: "Lebar Roll", val: "300 - 500 mm" },
        { key: "Panjang Roll", val: "100 - 1000 meter (Customizable)" },
        { key: "Warna", val: "Bening (Clear Transparent) & Hitam Opaque" },
        { key: "Aplikasi", val: "Wrapping Pallet Kargo, Ekspedisi, Gudang Manufaktur" }
      ]
    },
    {
      id: "plastic-opp",
      categoryId: "plastic",
      name: "Plastik OPP (Oriented Polypropylene)",
      categoryName: "Plastic",
      tag: "Spesifikasi PRD",
      badge: "Food & Garment",
      shortDesc: "Bening, kaku, mengilap; sangat cocok untuk kemasan makanan kering dan apparel garmen.",
      fullDesc: "Plastik OPP memiliki tingkat kejernihan transparansi yang sangat tinggi, bersifat kaku dan mengilap sehingga memberikan kesan visual produk yang premium dan higienis.",
      image: "https://images.unsplash.com/photo-1530587191325-3db32d826c18?auto=format&fit=crop&w=900&q=80",
      gallery: ["https://images.unsplash.com/photo-1530587191325-3db32d826c18?auto=format&fit=crop&w=900&q=80"],
      advantages: [
        "Permukaan bening kristal dan sangat mengilap",
        "Struktur material kaku dan rapi untuk kemasan pajang",
        "Tersedia varian lem seal (self-adhesive) praktis"
      ],
      specs: [
        { key: "Karakteristik", val: "Bening, kaku, mengilap" },
        { key: "Fungsi Utama", val: "Kemasan makanan kering, snack, bakery, packaging baju & stationery" },
        { key: "Format", val: "Sheet, Roll, Kantong Seal Tape" }
      ]
    },
    {
      id: "plastic-cpp",
      categoryId: "plastic",
      name: "Plastik CPP (Cast Polypropylene)",
      categoryName: "Plastic",
      tag: "Spesifikasi PRD",
      badge: "Heat Resistant",
      shortDesc: "Lentur, tahan panas, tidak mudah sobek; untuk kemasan makanan panas dan retort pouch.",
      fullDesc: "Plastik CPP memiliki sifat fleksibel dengan ketahanan terhadap suhu tinggi, daya rekat segel termal (heat sealing) yang kuat, serta ketahanan tusukan yang sangat andal.",
      image: "https://images.unsplash.com/photo-1587293852726-70cdb56c2866?auto=format&fit=crop&w=900&q=80",
      gallery: ["https://images.unsplash.com/photo-1587293852726-70cdb56c2866?auto=format&fit=crop&w=900&q=80"],
      advantages: [
        "Tahan suhu sterilisasi dan perebusan",
        "Sangat lentur dan daya sobek rendah",
        "Lapisan lamination sealing yang kokoh"
      ],
      specs: [
        { key: "Karakteristik", val: "Lentur, tahan panas, tidak mudah sobek" },
        { key: "Fungsi Utama", val: "Kemasan makanan panas, pasta, retort packaging" }
      ]
    },
    {
      id: "plastic-pvc",
      categoryId: "plastic",
      name: "Plastik PVC (Polyvinyl Chloride)",
      categoryName: "Plastic",
      tag: "Spesifikasi PRD",
      badge: "Rigid & Durable",
      shortDesc: "Kuat dan sedikit elastis; ideal untuk botol, pipa, serta kemasan blister pack industri.",
      fullDesc: "Material PVC menawarkan kekuatan mekanis tinggi, stabilitas dimensi prima, dan ketahanan kimia yang kuat untuk berbagai wadah dan proteksi blister part.",
      image: "https://images.unsplash.com/photo-1584813470613-5b1c1cad3d69?auto=format&fit=crop&w=900&q=80",
      gallery: ["https://images.unsplash.com/photo-1584813470613-5b1c1cad3d69?auto=format&fit=crop&w=900&q=80"],
      advantages: [
        "Struktur kokoh dan tahan terhadap benturan luar",
        "Ketahanan isolasi dan kimia industri",
        "Sangat presisi untuk cetak thermoforming / blister"
      ],
      specs: [
        { key: "Karakteristik", val: "Kuat dan sedikit elastis" },
        { key: "Fungsi Utama", val: "Botol industri, pipa, kemasan blister perkakas & farmasi" }
      ]
    },
    {
      id: "plastic-nylon",
      categoryId: "plastic",
      name: "Plastik Nylon (Polyamide Barrier)",
      categoryName: "Plastic",
      tag: "Spesifikasi PRD",
      badge: "Vacuum & Frozen",
      shortDesc: "Sangat kuat dan tahan suhu tinggi; untuk frozen food, daging, dan kemasan vacuum bag.",
      fullDesc: "Plastik Nylon dirancang dengan ketahanan gas barrier yang tinggi terhadap oksigen, menjamin kesegaran produk frozen food, daging olahan, dan makanan steril dalam jangka panjang.",
      image: "https://images.unsplash.com/photo-1587293852726-70cdb56c2866?auto=format&fit=crop&w=900&q=80",
      gallery: ["https://images.unsplash.com/photo-1587293852726-70cdb56c2866?auto=format&fit=crop&w=900&q=80"],
      advantages: [
        "Ketahanan hampa udara (vacuum barrier) terbaik",
        "Tahan suhu beku (freezer) tanpa pecah atau getas",
        "Kekuatan tarik dan tusukan sangat tinggi"
      ],
      specs: [
        { key: "Karakteristik", val: "Sangat kuat, tahan tusukan, dan tahan suhu tinggi" },
        { key: "Fungsi Utama", val: "Frozen food, daging olahan, vacuum packaging, seafood" }
      ]
    },
    {
      id: "plastic-pp",
      categoryId: "plastic",
      name: "Plastik PP (Polypropylene Food Grade)",
      categoryName: "Plastic",
      tag: "Spesifikasi PRD",
      badge: "Food Grade",
      shortDesc: "Kuat, tahan panas, dan aman untuk makanan; untuk gelas cup, kotak makanan, dan sedotan.",
      fullDesc: "Polimer PP berbobot ringan, berdaya tahan panas prima (tahan microwave), serta aman bersentuhan langsung dengan makanan (food grade).",
      image: "https://images.unsplash.com/photo-1583947215259-38e31be8751f?auto=format&fit=crop&w=900&q=80",
      gallery: ["https://images.unsplash.com/photo-1583947215259-38e31be8751f?auto=format&fit=crop&w=900&q=80"],
      advantages: [
        "Aman untuk makanan & minuman (BPA Free)",
        "Tahan panas suhu tinggi",
        "Ekonomis dan mudah didaur ulang"
      ],
      specs: [
        { key: "Karakteristik", val: "Kuat, tahan panas, dan aman untuk makanan" },
        { key: "Fungsi Utama", val: "Gelas cup plastik, kotak makanan catering, sedotan, tutup botol" }
      ]
    },
    {
      id: "plastic-pet",
      categoryId: "plastic",
      name: "Plastik PET (Polyethylene Terephthalate)",
      categoryName: "Plastic",
      tag: "Spesifikasi PRD",
      badge: "High Clarity",
      shortDesc: "Bening, ringan, tahan tekanan; untuk botol minuman dan kemasan makanan higienis.",
      fullDesc: "Plastik PET bening transparan menyerupai kaca namun tidak mudah pecah, kedap terhadap gas CO2, dan sangat ideal untuk kemasan botol minuman siap saji.",
      image: "https://images.unsplash.com/photo-1584813470613-5b1c1cad3d69?auto=format&fit=crop&w=900&q=80",
      gallery: ["https://images.unsplash.com/photo-1584813470613-5b1c1cad3d69?auto=format&fit=crop&w=900&q=80"],
      advantages: [
        "Transparansi sebening kaca",
        "Tahan tekanan internal botol minuman berkarbonasi",
        "Ringan dan higienis bersertifikasi"
      ],
      specs: [
        { key: "Karakteristik", val: "Bening, ringan, tahan tekanan" },
        { key: "Fungsi Utama", val: "Botol minuman, toples selai/bumbu, wadah blister makanan" }
      ]
    },
    {
      id: "plastic-ldpe",
      categoryId: "plastic",
      name: "Plastik LDPE (Low-Density Polyethylene)",
      categoryName: "Plastic",
      tag: "Spesifikasi PRD",
      badge: "Flexible Bag",
      shortDesc: "Lentur dan ringan; untuk kantong plastik, plastic wrap pelindung, dan kantong belanja.",
      fullDesc: "LDPE memiliki karakteristik lentur, kedap air, dan memiliki elastisitas baik, sangat cocok untuk kantong belanja tahan beban, plastik pelindung barang, dan liner pallet.",
      image: "https://images.unsplash.com/photo-1587293852726-70cdb56c2866?auto=format&fit=crop&w=900&q=80",
      gallery: ["https://images.unsplash.com/photo-1587293852726-70cdb56c2866?auto=format&fit=crop&w=900&q=80"],
      advantages: [
        "Fleksibel dan tidak mudah robek saat ditarik",
        "Tahan terhadap kelembapan tinggi",
        "Berbagai pilihan ketebalan dan ukuran kantong"
      ],
      specs: [
        { key: "Karakteristik", val: "Lentur dan ringan" },
        { key: "Fungsi Utama", val: "Kantong plastik industri, plastic wrap pelindung, kantong belanja" }
      ]
    },
    {
      id: "plastic-bubble-wrap",
      categoryId: "plastic",
      name: "Bubble Wrap Roll Industri",
      categoryName: "Plastic",
      tag: "Spesifikasi PRD",
      badge: "Cushioning",
      shortDesc: "Material gelembung udara berkualitas untuk membantu melindungi barang dari benturan fisik.",
      fullDesc: "Roll bubble wrap dengan gelembung udara padat dan elastis, memberikan perlindungan maksimal terhadap guncangan, benturan, dan goresan saat pengiriman ekspedisi logistik.",
      image: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=900&q=80",
      gallery: ["https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=900&q=80"],
      advantages: [
        "Gelembung udara padat dan tidak mudah kempis",
        "Melindungi barang pecah belah, elektronik, & kosmetik",
        "Mudah dipotong dan dibungkus mengikuti bentuk barang"
      ],
      specs: [
        { key: "Fungsi", val: "Membantu melindungi barang dari benturan & lecet" },
        { key: "Lebar Roll", val: "125 cm (Standard Industri)" },
        { key: "Panjang Roll", val: "50 meter per roll / custom" },
        { key: "Pilihan Warna", val: "Bening (Clear) & Hitam (Black)" }
      ]
    },
    // Packaging
    {
      id: "kardus-corrugated",
      categoryId: "packaging",
      name: "Kardus Karton Corrugated Box",
      categoryName: "Packaging",
      tag: "Solusi Kemasan",
      badge: "Heavy Duty",
      shortDesc: "Solusi kemasan kardus bergelombang untuk pengemasan makanan, elektronik, kosmetik, hingga pengiriman barang.",
      fullDesc: "Karton box corrugated berkualitas tinggi dengan pilihan Single Wall, Double Wall, dan Triple Wall untuk memastikan keamanan penyimpanan di rak gudang serta distribusi antarpulau.",
      image: "https://images.unsplash.com/photo-1530587191325-3db32d826c18?auto=format&fit=crop&w=900&q=80",
      gallery: ["https://images.unsplash.com/photo-1530587191325-3db32d826c18?auto=format&fit=crop&w=900&q=80"],
      advantages: [
        "Tahan tumpukan beban tinggi di gudang",
        "Dapat dicetak logo & instruksi penanganan (custom print)",
        "Material ramah lingkungan dan dapat didaur ulang"
      ],
      specs: [
        { key: "Tipe Flute", val: "B/F, C/F, E/F, Single Wall (3 ply) & Double Wall (5 ply)" },
        { key: "Ketahanan Beban", val: "Hingga 50+ kg tergantung konstruksi" },
        { key: "Ukuran", val: "Customized sesuai kebutuhan packaging klien" }
      ]
    },
    {
      id: "strapping-band",
      categoryId: "packaging",
      name: "Strapping Band & Lakban OPP Tape",
      categoryName: "Packaging",
      tag: "Packaging Supply",
      badge: "Logistik",
      shortDesc: "Tali strapping mesin/manual dan lakban perekat kuat untuk pengikatan koli dan karton.",
      fullDesc: "Perlengkapan bundling karton dan pengikatan beban berat pada pallet menggunakan tali strapping PP/PET dan isolasi OPP tape dengan lem water-based tahan suhu ekstrem.",
      image: "https://images.unsplash.com/photo-1587293852726-70cdb56c2866?auto=format&fit=crop&w=900&q=80",
      gallery: ["https://images.unsplash.com/photo-1587293852726-70cdb56c2866?auto=format&fit=crop&w=900&q=80"],
      advantages: [
        "Daya rekat tinggi tidak mudah terkelupas di suhu dingin/panas",
        "Kekuatan tarik strapping band tinggi untuk mengikat muatan berat",
        "Tersedia warna bening, cokelat, dan custom cetak logo brand"
      ],
      specs: [
        { key: "Tipe Lakban", val: "OPP Tape Bening & Cokelat (48mm x 90-100 yard)" },
        { key: "Tali Strapping", val: "PP Strapping Band 9mm, 12mm, 15mm (Hand & Machine)" }
      ]
    },
    // Office Stationery
    {
      id: "office-stationery-bundle",
      categoryId: "stationery",
      name: "Perlengkapan ATK Kantor Lengkap",
      categoryName: "Office Stationery",
      tag: "Pengadaan Kantor",
      badge: "ATK Bisnis",
      shortDesc: "Pulpen, pensil, spidol, buku tulis, map ordner, dan perlengkapan kantor untuk operasional perusahaan.",
      fullDesc: "Solusi pengadaan rutin alat tulis kantor (ATK) skala grosir dan retail corporate untuk kebutuhan operasional kantor, instansi, dan cabang perusahaan tanpa repot.",
      image: "https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?auto=format&fit=crop&w=900&q=80",
      gallery: ["https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?auto=format&fit=crop&w=900&q=80"],
      advantages: [
        "Katalog produk ATK lengkap dari berbagai merek terpercaya",
        "Harga pengadaan grosir B2B efisien dengan suplai terjadwal",
        "Faktur pajak dan legalitas transaksi perusahaan lengkap"
      ],
      specs: [
        { key: "Kategori Produk", val: "Kertas HVS (A4, F4), Pulpen, Spidol Whiteboard/Permanent" },
        { key: "Pengarsipan", val: "Ordner Bantex, Map Business File, Binder, Clear Holder" },
        { key: "Aksesoris", val: "Stapler, Puncher, Paper Clip, Correction Tape, Notes" }
      ]
    },
    // Safety Equipment
    {
      id: "safety-equipment-set",
      categoryId: "safety",
      name: "Perlengkapan Safety & APD K3",
      categoryName: "Safety Equipment",
      tag: "Standar K3",
      badge: "Perlindungan Pekerja",
      shortDesc: "Mendukung perlindungan pekerja dari berbagai potensi bahaya di lingkungan kerja proyek & industri.",
      fullDesc: "Rangkaian Alat Pelindung Diri (APD) bersertifikasi SNI dan standar internasional (ANSI/CE) untuk menjamin keselamatan tenaga kerja di pabrik, gudang, konstruksi, dan area berisiko tinggi.",
      image: "https://images.unsplash.com/photo-1578575437130-527eed3abbec?auto=format&fit=crop&w=900&q=80",
      gallery: ["https://images.unsplash.com/photo-1578575437130-527eed3abbec?auto=format&fit=crop&w=900&q=80"],
      advantages: [
        "Memenuhi standar kepatuhan regulasi K3 nasional",
        "Material tangguh, ergonomis, dan nyaman dipakai shift panjang",
        "Tersedia lengkap dari kepala hingga kaki"
      ],
      specs: [
        { key: "Item Helm", val: "Safety Helmet V-Gard dengan tali dagu & suspensi putar" },
        { key: "Item Rompi", val: "Rompi Safety Reflektif Scotlight (Jaring/Polyester)" },
        { key: "Item Kaki & Tangan", val: "Sepatu Safety Steel Toe Cap & Sarung Tangan PU/Nitrile/Katun" }
      ]
    },
    // Chemical
    {
      id: "industrial-cleaning-chemical",
      categoryId: "chemical",
      name: "Chemical & Pembersih Area Operasional",
      categoryName: "Chemical",
      tag: "Chemical Terstandar",
      badge: "Kebersihan & Sanitasi",
      shortDesc: "Pembersih lantai, pembersih kaca, pengharum ruangan, dan chemical sanitasi industri.",
      fullDesc: "Menyediakan kebutuhan formula pembersih konsentrat untuk gedung perkantoran, fasilitas manufaktur, rumah sakit, dan area komersial dengan efektivitas pembersihan tinggi.",
      image: "https://images.unsplash.com/photo-1584813470613-5b1c1cad3d69?auto=format&fit=crop&w=900&q=80",
      gallery: ["https://images.unsplash.com/photo-1584813470613-5b1c1cad3d69?auto=format&fit=crop&w=900&q=80"],
      advantages: [
        "Konsentrasi tinggi sehingga sangat hemat pemakaian",
        "Aman untuk berbagai jenis permukaan lantai (epoxy, keramik, granit)",
        "Disertai Material Safety Data Sheet (MSDS) resmi"
      ],
      specs: [
        { key: "Produk Utama", val: "Floor Cleaner, Glass Cleaner, Hand Soap, Disinfektan" },
        { key: "Kemasan", val: "Jerigen 4 Liter, 5 Liter, hingga Drum 20-25 Liter" }
      ]
    },
    // Consumable
    {
      id: "operational-consumables",
      categoryId: "consumable",
      name: "Consumable Operasional & Kantong Sampah",
      categoryName: "Consumable",
      tag: "Kebutuhan Rutin",
      badge: "Fasilitas Kerja",
      shortDesc: "Berbagai kebutuhan consumable rutin untuk mendukung aktivitas bisnis dan operasional harian.",
      fullDesc: "Penyediaan barang habis pakai rutin seperti trash bag medis/non-medis, tissue dispenser, sarung tangan disposable, dan perlengkapan pantry perusahaan.",
      image: "https://images.unsplash.com/photo-1583947215259-38e31be8751f?auto=format&fit=crop&w=900&q=80",
      gallery: ["https://images.unsplash.com/photo-1583947215259-38e31be8751f?auto=format&fit=crop&w=900&q=80"],
      advantages: [
        "Ketersediaan stok stabil untuk kontrak pasokan bulanan",
        "Kualitas bahan tebal tidak mudah bocor atau robek",
        "Pengiriman terjadwal sesuai ritme operasional perusahaan"
      ],
      specs: [
        { key: "Plastik Sampah", val: "Trash Bag Hitam HD/PE (60x100, 80x100, 90x120 cm)" },
        { key: "Produk Tissue", val: "Hand Towel Roll, Facial Tissue, Toilet Paper Jumbo Roll" }
      ]
    },
    // Printing
    {
      id: "commercial-printing-solutions",
      categoryId: "printing",
      name: "Layanan Cetak Dokumen & Promosi Bisnis",
      categoryName: "Printing",
      tag: "Percetakan Korporat",
      badge: "Branding & Dokumen",
      shortDesc: "Produk cetak formulir, label barcode sticker, nota rangkap NCR, dan materi promosi korporat.",
      fullDesc: "Solusi cetak offset dan digital presisi tinggi untuk mendukung branding perusahaan, administrasi logistik gudang, dan materi presentasi bisnis dengan warna akurat.",
      image: "https://images.unsplash.com/photo-1562654501-a0ccc0fc3fb1?auto=format&fit=crop&w=900&q=80",
      gallery: ["https://images.unsplash.com/photo-1562654501-a0ccc0fc3fb1?auto=format&fit=crop&w=900&q=80"],
      advantages: [
        "Hasil cetak tajam, presisi warna konsisten dengan standar proofing",
        "Kertas NCR sensitif berkualitas tinggi untuk surat jalan / faktur",
        "Stiker label barcode berperekat kuat tahan gesekan & kelembapan"
      ],
      specs: [
        { key: "Dokumen Kantor", val: "Buku Nota NCR Rangkap 2-4, Kop Surat, Amplop Perusahaan" },
        { key: "Label Logistik", val: "Stiker Thermal Barcode, Stiker Fragile, Label Kemasan" },
        { key: "Marketing", val: "Brosur, Company Profile Booklet, Spanduk & Roll Banner" }
      ]
    }
  ],

  clients: [
    {
      id: "client-hitachi",
      name: "PT. Hitachi Construction Machinery Indonesia",
      shortName: "Hitachi",
      logo: "assets/logos/client-hitachi.svg",
      industry: "Heavy Machinery & Construction"
    },
    {
      id: "client-mics",
      name: "PT MICS STEEL INDONESIA",
      shortName: "MICS Steel",
      logo: "assets/logos/client-mics.svg",
      industry: "Steel & Metallurgy Manufacturing"
    },
    {
      id: "client-kandia",
      name: "Kandia Tirta Engineering",
      shortName: "Kandia Tirta",
      logo: "assets/logos/client-kandia.svg",
      industry: "Engineering & Water Solutions"
    },
    {
      id: "client-tms",
      name: "PT Tembaga Mulia Semanan, Tbk",
      shortName: "TMS",
      logo: "assets/logos/client-tms.svg",
      industry: "Copper & Wire Manufacturing"
    },
    {
      id: "client-chengtian",
      name: "PT. Chengtian Weiye Indonesia",
      shortName: "Chengtian Weiye",
      logo: "assets/logos/client-chengtian.svg",
      industry: "Smart Card & Electronics"
    },
    {
      id: "client-adhibeton",
      name: "PT Adhimix Precast Indonesia",
      shortName: "Adhibeton",
      logo: "assets/logos/client-adhibeton.svg",
      industry: "Ready-Mix Concrete & Precast"
    },
    {
      id: "client-enkei",
      name: "ENKEI INDONESIA",
      shortName: "ENKEI",
      logo: "assets/logos/client-enkei.svg",
      industry: "Automotive Wheel Manufacturing"
    },
    {
      id: "client-anugerah",
      name: "PT. ANUGERAH CIPTA KREASINDO",
      shortName: "PT. AK",
      logo: "assets/logos/client-anugerah.svg",
      industry: "Technology & Industrial Consulting"
    }
  ],

  gallery: [
    {
      id: "gal-1",
      title: "Kegiatan Distribusi",
      category: "Distribusi",
      desc: "Proses pemuatan dan penyiapan muatan produk suplai untuk pengiriman tepat waktu ke gudang pelanggan.",
      image: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=800&q=80"
    },
    {
      id: "gal-2",
      title: "Warehouse & Storage",
      category: "Fasilitas",
      desc: "Manajemen penyimpanan stok barang dengan sistem racking teratur dan terjaga kebersihannya.",
      image: "https://images.unsplash.com/photo-1587293852726-70cdb56c2866?auto=format&fit=crop&w=800&q=80"
    },
    {
      id: "gal-3",
      title: "Meeting / Office",
      category: "Aktivitas",
      desc: "Koordinasi internal tim pengadaan dan konsultasi spesifikasi kebutuhan solusi mitra bisnis.",
      image: "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&w=800&q=80"
    },
    {
      id: "gal-4",
      title: "Armada Pengiriman",
      category: "Logistik",
      desc: "Armada logistik terpercaya siap menjangkau berbagai kawasan industri di Jabodetabek dan sekitarnya.",
      image: "https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&w=800&q=80"
    },
    {
      id: "gal-5",
      title: "Aktivitas Perusahaan",
      category: "Operasional",
      desc: "Pemeriksaan kualitas berkala (quality check) memastikan barang yang dikirim sesuai standar spesifikasi.",
      image: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=800&q=80"
    },
    {
      id: "gal-6",
      title: "Tim & Konsultasi",
      category: "Human Capital",
      desc: "Tim profesional kami yang berkomitmen mendampingi setiap tahapan pengadaan perusahaan Anda.",
      image: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=800&q=80"
    }
  ],

  translations: {
    id: {
      nav: {
        home: "Beranda",
        about: "Tentang Kami",
        products: "Produk",
        solutions: "Solusi",
        whyUs: "Mengapa Kanaya",
        clients: "Klien Kami",
        gallery: "Dokumentasi",
        contact: "Kontak",
        ctaButton: "Hubungi Kami"
      }
    },
    en: {
      nav: {
        home: "Home",
        about: "About Us",
        products: "Products",
        solutions: "Solutions",
        whyUs: "Why Kanaya",
        clients: "Our Clients",
        gallery: "Gallery",
        contact: "Contact",
        ctaButton: "Contact Us"
      }
    }
  }
};

/**
 * Firebase Firestore Cloud Configuration & Client
 */
const KMS_FIREBASE_CONFIG = {
  apiKey: "AIzaSyC2Qbc1qWT8FIPK9CT7dpPgJySY3_OzG1A",
  authDomain: "kanaya-multi-solusindo.firebaseapp.com",
  projectId: "kanaya-multi-solusindo",
  storageBucket: "kanaya-multi-solusindo.firebasestorage.app",
  messagingSenderId: "779738839192",
  appId: "1:779738839192:web:df3b952da43f07d87538ed"
};

let kmsDb = null;
try {
  if (typeof firebase !== 'undefined') {
    if (!firebase.apps.length) {
      firebase.initializeApp(KMS_FIREBASE_CONFIG);
    }
    kmsDb = firebase.firestore();
    console.log('✅ Firebase Firestore terhubung sukses.');
  } else {
    console.warn('⚠️ Firebase SDK belum dimuat, fallback ke LocalStorage.');
  }
} catch (err) {
  console.warn('⚠️ Inisialisasi Firebase error:', err);
}

/**
 * Reactive LocalStorage + Cloud Firestore Data Layer
 */
const STORAGE_KEY = 'KMS_APP_DATA_V3';
const INQUIRIES_KEY = 'KMS_INQUIRIES_V2';
const AUTH_KEY = 'KMS_ADMIN_AUTH_V2';

function loadKmsData() {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      // Deep merge with defaults to ensure all nested keys exist
      const merged = Object.assign({}, DEFAULT_KMS_DATA, parsed);
      if (parsed.company) {
        merged.company = Object.assign({}, DEFAULT_KMS_DATA.company, parsed.company);
        if (parsed.company.contacts) {
          merged.company.contacts = Object.assign({}, DEFAULT_KMS_DATA.company.contacts, parsed.company.contacts);
        }
      }
      // Guarantee updated hero slides with clean high-res images & highlights
      if (!parsed.heroSlides || parsed.heroSlides.some(s => !s.highlights || s.image.includes('1605600659908'))) {
        merged.heroSlides = JSON.parse(JSON.stringify(DEFAULT_KMS_DATA.heroSlides));
      }
      return merged;
    }
  } catch (e) {
    console.warn('Error reading localStorage, using defaults:', e);
  }
  return JSON.parse(JSON.stringify(DEFAULT_KMS_DATA));
}

function saveKmsData(data) {
  // 1. Simpan ke LocalStorage seketika untuk kecepatan lokal & offline fallback
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (e) {
    console.error('Error saving to localStorage:', e);
  }

  // 2. Simpan & Sinkronkan langsung ke Cloud Firebase Firestore
  if (kmsDb) {
    kmsDb.collection('cms').doc('website_data').set(data)
      .then(() => {
        console.log('☁️ Data website berhasil disinkronkan ke Cloud Firestore.');
        showSyncNotice('Tersimpan di Cloud Firebase');
      })
      .catch((err) => {
        console.error('❌ Gagal sinkron ke Cloud Firestore:', err);
      });
  }
}

function resetKmsDataToDefault() {
  localStorage.removeItem(STORAGE_KEY);
  window.KMS_DATA = JSON.parse(JSON.stringify(DEFAULT_KMS_DATA));
  saveKmsData(window.KMS_DATA);
}

// Inquiries Storage
function loadInquiries() {
  try {
    const raw = localStorage.getItem(INQUIRIES_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    return [];
  }
}

function saveInquiry(inquiry) {
  const list = loadInquiries();
  inquiry.id = 'INQ-' + Date.now();
  inquiry.createdAt = new Date().toLocaleString('id-ID');
  inquiry.createdAtMs = Date.now();
  inquiry.status = 'Baru';
  list.unshift(inquiry);
  try {
    localStorage.setItem(INQUIRIES_KEY, JSON.stringify(list));
  } catch (e) {}

  // Simpan inquiry ke Firebase Firestore agar dapat diakses admin dari mana saja
  if (kmsDb) {
    kmsDb.collection('inquiries').add(inquiry)
      .then((docRef) => {
        inquiry._firestoreId = docRef.id;
        console.log('☁️ Inquiry pengadaan berhasil masuk ke Cloud Firestore:', docRef.id);
      })
      .catch((err) => {
        console.error('❌ Gagal simpan inquiry ke Firestore:', err);
      });
  }

  return inquiry;
}

// Helper notice sinkronisasi cloud
function showSyncNotice(msg) {
  let toast = document.getElementById('kms-sync-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'kms-sync-toast';
    toast.className = 'fixed bottom-5 right-5 z-[9999] bg-emerald-600 text-white text-xs font-semibold px-4 py-2.5 rounded-xl shadow-xl flex items-center gap-2 transition-all duration-300 opacity-0 pointer-events-none transform translate-y-2';
    toast.innerHTML = '<span class="w-2 h-2 rounded-full bg-emerald-200 animate-ping"></span><span id="kms-sync-msg"></span>';
    document.body.appendChild(toast);
  }
  const msgEl = document.getElementById('kms-sync-msg');
  if (msgEl) msgEl.textContent = msg;
  toast.classList.remove('opacity-0', 'pointer-events-none', 'translate-y-2');
  setTimeout(() => {
    toast.classList.add('opacity-0', 'pointer-events-none', 'translate-y-2');
  }, 2500);
}

// Initialize Global Data Instance
window.KMS_DATA = loadKmsData();

// Real-Time Cloud Synchronization Listener
function initCloudSync() {
  if (!kmsDb) return;

  // 1. Dengarkan pembaruan data website dari Firestore secara langsung
  kmsDb.collection('cms').doc('website_data').onSnapshot((doc) => {
    if (doc.exists) {
      const cloudData = doc.data();
      const merged = Object.assign({}, DEFAULT_KMS_DATA, cloudData);
      if (cloudData.company) {
        merged.company = Object.assign({}, DEFAULT_KMS_DATA.company, cloudData.company);
        if (cloudData.company.contacts) {
          merged.company.contacts = Object.assign({}, DEFAULT_KMS_DATA.company.contacts, cloudData.company.contacts);
        }
      }
      window.KMS_DATA = merged;
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
        if (cloudData.adminUsername) {
          localStorage.setItem('KMS_CUSTOM_USER', cloudData.adminUsername);
        }
        if (cloudData.adminPassword) {
          localStorage.setItem('KMS_CUSTOM_PASS', cloudData.adminPassword);
        }
      } catch(e) {}

      // Perbarui tampilan publik jika halaman utama sedang terbuka
      if (typeof refreshAllPublicContent === 'function') {
        refreshAllPublicContent();
      }
      // Perbarui hero slides jika fungsi tersedia
      if (typeof window.renderHeroSlides === 'function') {
        window.renderHeroSlides();
      }
      // Perbarui dashboard admin jika admin sedang membukanya
      if (typeof initAdminDashboard === 'function' && window.location.hash.includes('admin')) {
        initAdminDashboard();
      }
    } else {
      // Jika data di Firestore masih kosong, unggah data default secara otomatis
      console.log('☁️ Mengunggah data awal bawaan ke Cloud Firestore...');
      kmsDb.collection('cms').doc('website_data').set(window.KMS_DATA)
        .catch(err => console.warn('Gagal upload data awal:', err));
    }
  }, (err) => {
    console.warn('Firestore real-time sync warning:', err);
  });

  // 2. Dengarkan data Inquiries dari Firestore secara realtime untuk Admin
  kmsDb.collection('inquiries').onSnapshot((snapshot) => {
    const cloudInquiries = [];
    snapshot.forEach((doc) => {
      const item = doc.data();
      item._firestoreId = doc.id;
      cloudInquiries.push(item);
    });
    cloudInquiries.sort((a, b) => (b.createdAtMs || 0) - (a.createdAtMs || 0));
    try {
      localStorage.setItem(INQUIRIES_KEY, JSON.stringify(cloudInquiries));
    } catch(e) {}

    if (typeof renderAdminInquiries === 'function' && window.location.hash.includes('admin')) {
      renderAdminInquiries();
    }
    if (typeof updateAdminStats === 'function' && window.location.hash.includes('admin')) {
      updateAdminStats();
    }
  }, (err) => {
    console.warn('Firestore inquiries sync warning:', err);
  });

  // 3. Dengarkan data Analitik Kunjungan dari Firestore secara realtime
  kmsDb.collection('cms').doc('analytics').onSnapshot((doc) => {
    if (doc.exists) {
      window.KMS_ANALYTICS = doc.data();
      if (typeof renderAdminAnalytics === 'function' && window.location.hash.includes('admin')) {
        renderAdminAnalytics();
      }
    }
  }, (err) => {
    console.warn('Firestore analytics sync warning:', err);
  });

  // Jalankan pelacakan pengunjung jika bukan admin
  if (!window.location.hash.includes('admin')) {
    trackVisitor();
  }
}

/**
 * Mesin Pelacak Kunjungan Pengunjung Website (Real-time Analytics)
 */
function trackVisitor() {
  if (!kmsDb || typeof firebase === 'undefined') return;
  try {
    const today = new Date().toISOString().split('T')[0];
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    
    let visId = localStorage.getItem('KMS_VISITOR_ID');
    let isNewVisitor = false;
    if (!visId) {
      visId = 'v_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now();
      localStorage.setItem('KMS_VISITOR_ID', visId);
      isNewVisitor = true;
    }

    const lastVisit = localStorage.getItem('KMS_LAST_VISIT_DATE');
    const isNewToday = (lastVisit !== today);
    if (isNewToday) {
      localStorage.setItem('KMS_LAST_VISIT_DATE', today);
    }

    const inc = firebase.firestore.FieldValue.increment(1);
    const updateData = {
      totalViews: inc,
      lastUpdated: new Date().toISOString()
    };
    if (isNewVisitor) {
      updateData.uniqueVisitors = inc;
    }
    if (isMobile) {
      updateData.mobileViews = inc;
    } else {
      updateData.desktopViews = inc;
    }
    updateData[`views_${today}`] = inc;

    kmsDb.collection('cms').doc('analytics').set(updateData, { merge: true })
      .catch(err => console.warn('Gagal mencatat analitik:', err));
  } catch(e) {
    console.warn('Pelacakan analitik dilewati:', e);
  }
}

// Jalankan Cloud Sync setelah halaman siap
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initCloudSync);
} else {
  initCloudSync();
}
